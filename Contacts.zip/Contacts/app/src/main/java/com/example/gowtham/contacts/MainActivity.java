package com.example.gowtham.contacts;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView rv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rv=findViewById(R.id.recycleview);
        MyTask task=new MyTask();
        task.execute();
    }

    public class MyTask extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url=new URL("https://api.androidhive.info/contacts/");
                HttpURLConnection  connection= (HttpURLConnection) url.openConnection();
                InputStream is=connection.getInputStream();
                BufferedReader br=new BufferedReader(new InputStreamReader(is));
                String line=null;
                StringBuilder builder=new StringBuilder();
                while ((line=br.readLine())!=null){
                    builder.append("/n"+line);


                }
                return builder.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            Toast.makeText(MainActivity.this, ""+s, Toast.LENGTH_SHORT).show();
            ArrayList<ContactsModel> list=new ArrayList();

            try {
                JSONObject object=new JSONObject();
                JSONArray jsonArray=object.getJSONArray("contacts");
                for (int i=0;i<jsonArray.length();i++){
                    JSONObject j1=jsonArray.getJSONObject(i);
                    String name =j1.optString("name");
                    String email=j1.optString("email");
                    JSONObject j2=j1.getJSONObject("phone");
                    String phoneNo=j2.optString("mobile");

                    ContactsModel model=new ContactsModel(name,email,phoneNo);
                    list.add(model);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
            rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
            rv.setAdapter(new MyAdaapter(MainActivity.this,list));
        }
    }

}
