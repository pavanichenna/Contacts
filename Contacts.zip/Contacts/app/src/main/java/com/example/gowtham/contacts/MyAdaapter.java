package com.example.gowtham.contacts;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

class MyAdaapter extends RecyclerView.Adapter<MyAdaapter.MyViewHolder>{
    ArrayList<ContactsModel> mymodel;
    Context ct;

    public MyAdaapter(MainActivity mainActivity, ArrayList<ContactsModel> list) {
        mymodel=list;
        ct=mainActivity;
    }

    @NonNull
    @Override
    public MyAdaapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v=LayoutInflater.from(ct).inflate(R.layout.contacts,viewGroup,false);
        MyViewHolder holder =new MyViewHolder(v);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdaapter.MyViewHolder myViewHolder, int i) {
        ContactsModel model=mymodel.get(i);
        myViewHolder.cname.setText(model.getName());
        myViewHolder.cmail.setText(model.getEmail());
        myViewHolder.cphone.setText(model.getPhoneNo());

    }

    @Override
    public int getItemCount() {
        return mymodel.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView cname,cmail,cphone;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cname=itemView.findViewById(R.id.name);
            cmail=itemView.findViewById(R.id.email);
            cphone=itemView.findViewById(R.id.phoneNo);
        }
    }
}
